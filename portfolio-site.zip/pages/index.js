
import { motion } from 'framer-motion';
import { Linkedin, Download } from 'lucide-react';

export default function Home() {
  return (
    <div className="bg-gradient-to-br from-gray-950 via-gray-900 to-black min-h-screen text-gray-100">
      <nav className="py-6 px-8 flex justify-between items-center border-b border-gray-700">
        <h1 className="text-3xl font-semibold text-teal-400">Sai Kumar Kaipelly</h1>
        <ul className="flex gap-8 text-lg">
          <li><a className="hover:text-teal-400 transition duration-300" href="#about">About</a></li>
          <li><a className="hover:text-teal-400 transition duration-300" href="#experience">Experience</a></li>
          <li><a className="hover:text-teal-400 transition duration-300" href="#skills">Skills</a></li>
          <li><a className="hover:text-teal-400 transition duration-300" href="#contact">Contact</a></li>
        </ul>
      </nav>

      <main className="container mx-auto px-8 py-16">
        <motion.section
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7 }}
          className="text-center my-32"
        >
          <h2 className="text-6xl font-extrabold mb-4">Java Full Stack Developer</h2>
          <p className="text-xl mb-8">Crafting modern web solutions with Java, React, Angular, and AWS.</p>
          <div className="flex justify-center gap-4">
            <a href="/Sai_Kumar_Kaipelly_Java_Full_Stack_Developer.pdf" download className="inline-flex items-center px-6 py-3 bg-teal-500 hover:bg-teal-600 rounded-lg shadow-lg transition-transform transform hover:scale-105">
              <Download className="mr-2" /> Resume
            </a>
            <a href="https://www.linkedin.com/in/saikumarkaipelly" target="_blank" className="inline-flex items-center px-6 py-3 bg-gray-800 hover:bg-gray-700 rounded-lg shadow-lg transition-transform transform hover:scale-105">
              <Linkedin className="mr-2" /> LinkedIn
            </a>
          </div>
        </motion.section>
      </main>
    </div>
  );
}
